## Question 3

This folder comprises of codes and datasets used for Q3 of the Group projects.
The libraries used for this question are:
- pandas
- seaborn
- numpy
- matplotlib
- datetime
- plotly
- scipy
- geopandas
- statsmodels

Detailed description of the code is avalable under the documentation folder.
