### Question 2

##### Approach for the Question 2:

- Perform statistics of data, do some visualizations as well to understand the data - Pandas and Seaborn is a good combination
- Partition data for training and test - Use SKlearn 
- Code for logistic regression and find a suitable decision or objective function 
- Write code for gradient descent algorithm -- Andrew NG Code can be extended for the same 
- Choose proper initialization values to avoid local optimals or saddle points and make sure it converges to global minima
- Score the model and output the confustion matrix and F-1 Score  