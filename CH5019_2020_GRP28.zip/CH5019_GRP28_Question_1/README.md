### Question 1

##### Approach for the Question 1:

- Understand how to generate the Representative Image of the group using SVD 
- Work on the first dataset to generate the representative image and try to see the accuracy of the image prediction
- Perform the same operation for all the groups and generate Representative Images of the groups
- For a given image calculate the norm with the representative images and assign the one with minimal norm as the tag
- Predict the accuracy for all the images in database and obtain the accuracy